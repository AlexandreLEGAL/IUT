#!/usr/bin/python3
# ===========
# Les données
# ===========

morticia="Morticia Adams"
courses_morticia=["bave de crapeau", "oeufs de dragon", "sang de lézard", "ketchup", "sel"]
facture_morticia=[24, 157, 17, 2, 1]

gomez="Gomez Adams"
courses_gomez=["chaussures de tango", "couteau", "explosif", "sumac veneneux"]
facture_gomez=[247, 15, 167, 27]

# ================================
# Outils de traitement des données
# ================================

def somme(liste):
    return 0
