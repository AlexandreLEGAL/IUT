#!/usr/bin/python3
# =====================
# NOM : 
# ====================

from jinja2 import Environment, FileSystemLoader  # ne pas modifier cette ligne
from vaisseauxSW_modele  import *

# ne modifiez pas cette fonction
def creer_html(fichier_template, fichier_sortie,**infos):
    env = Environment(loader=FileSystemLoader('.'),trim_blocks=True)
    template = env.get_template(fichier_template)
    html=template.render(infos)
    f = open(fichier_sortie, 'w')
    f.write(html)
    f.close()

